package com.example.devcontabiliza;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "study_tracker.db";
    private static final int DATABASE_VERSION = 1;

    // Tabela de usuários
    private static final String TABLE_USERS = "users";
    private static final String COLUMN_USER_ID = "user_id";
    private static final String COLUMN_USER_USERNAME = "username";
    private static final String COLUMN_USER_PASSWORD = "password";
    private static final String COLUMN_USER_LANGUAGE = "study_language";
    private static final String COLUMN_USER_DAILY_GOAL = "daily_goal";
    private static final String COLUMN_USER_DAYS_STUDIED = "days_studied";
    private static final String COLUMN_USER_CURRENT_STREAK = "current_streak";

    // Tabela de registros de estudo
    private static final String TABLE_STUDY_RECORDS = "study_records";
    private static final String COLUMN_STUDY_RECORD_ID = "study_record_id";
    private static final String COLUMN_STUDY_RECORD_USER_ID = "user_id";
    private static final String COLUMN_STUDY_RECORD_DATE = "date";
    private static final String COLUMN_STUDY_RECORD_CONTENT = "content";

    // Formatador de data para armazenar no banco de dados
    private static final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        // Tabela de usuários
        String createUsersTable = "CREATE TABLE " + TABLE_USERS + "("
                + COLUMN_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COLUMN_USER_USERNAME + " TEXT UNIQUE,"
                + COLUMN_USER_PASSWORD + " TEXT,"
                + COLUMN_USER_LANGUAGE + " TEXT,"
                + COLUMN_USER_DAILY_GOAL + " INTEGER,"
                + COLUMN_USER_DAYS_STUDIED + " INTEGER DEFAULT 0,"
                + COLUMN_USER_CURRENT_STREAK + " INTEGER DEFAULT 0"
                + ")";
        db.execSQL(createUsersTable);

        // Tabela de registros de estudo
        String createStudyRecordsTable = "CREATE TABLE " + TABLE_STUDY_RECORDS + "("
                + COLUMN_STUDY_RECORD_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COLUMN_STUDY_RECORD_USER_ID + " INTEGER,"
                + COLUMN_STUDY_RECORD_DATE + " TEXT,"
                + COLUMN_STUDY_RECORD_CONTENT + " TEXT"
                + ")";
        db.execSQL(createStudyRecordsTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Lógica para atualizar o banco de dados quando a versão mudar
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_STUDY_RECORDS);
        onCreate(db);
    }

    // Método para inserir um novo usuário
    public void insertUser(String username, String password, String language, int dailyGoal) {
        SQLiteDatabase db = null;
        try {
            db = this.getWritableDatabase();
            ContentValues values = new ContentValues();
            values.put(COLUMN_USER_USERNAME, username);
            values.put(COLUMN_USER_PASSWORD, password);
            values.put(COLUMN_USER_LANGUAGE, language);
            values.put(COLUMN_USER_DAILY_GOAL, dailyGoal);
            long id = db.insert(TABLE_USERS, null, values);
            if (id == -1) {
                Log.e("DatabaseHelper", "Erro ao inserir usuário");
            }
        } catch (SQLiteException e) {
            Log.e("DatabaseHelper", "Erro ao inserir usuário: " + e.getMessage());
            // Lança a exceção para ser tratada na Activity
            throw e;
        } finally {
            if (db != null) {
                db.close();
            }
        }
    }

    // Método para verificar as credenciais do usuário
    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = null;
        Cursor cursor = null;
        try {
            db = this.getReadableDatabase();
            String[] columns = {COLUMN_USER_ID};
            String selection = COLUMN_USER_USERNAME + " = ? AND " + COLUMN_USER_PASSWORD + " = ?";
            String[] selectionArgs = {username, password};
            cursor = db.query(TABLE_USERS, columns, selection, selectionArgs, null, null, null);
            return cursor.moveToFirst();
        } catch (SQLiteException e) {
            Log.e("DatabaseHelper", "Erro ao verificar usuário: " + e.getMessage());
            return false;
        } finally {
            if (cursor != null) {
                cursor.close();
            }
            if (db != null) {
                db.close();
            }
        }
    }

    // Método para inserir um novo registro de estudo
    public void insertStudyRegister(Estudo estudo) {
        SQLiteDatabase db = null;
        try {
            db = this.getWritableDatabase();
            ContentValues values = new ContentValues();
            values.put(COLUMN_STUDY_RECORD_USER_ID, estudo.getUserId());
            values.put(COLUMN_STUDY_RECORD_DATE, dateFormat.format(estudo.getDate()));
            values.put(COLUMN_STUDY_RECORD_CONTENT, estudo.getContent());
            long id = db.insert(TABLE_STUDY_RECORDS, null, values);
            if (id == -1) {
                Log.e("DatabaseHelper", "Erro ao inserir registro de estudo");
                throw new SQLiteException("Erro ao inserir registro de estudo");
            } else {
                // Chama o método para atualizar os dados do usuário APÓS inserir o registro com sucesso
                updateUserStudyData(estudo.getUserId());
            }
        } catch (SQLiteException e) {
            Log.e("DatabaseHelper", "Erro ao inserir registro de estudo: " + e.getMessage());
            throw e;
        } finally {
            if (db != null) {
                db.close();
            }
        }
    }

    // Método para atualizar a data de estudo do usuário
    private void updateUserStudyData(int userId) {
        SQLiteDatabase db = null;
        try {
            db = this.getWritableDatabase();
            Date lastStudyDate = getLastStudyDate(userId);
            int currentStreak = getCurrentStreak(userId);
            Date currentDate = new Date();
            if (lastStudyDate == null) {
                currentStreak = 1;
            } else {
                long diff = currentDate.getTime() - lastStudyDate.getTime();
                long daysDifference = TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS);
                if (daysDifference == 1) {
                    currentStreak++;
                } else if (daysDifference > 1) {
                    currentStreak = 1;
                }
            }
            ContentValues values = new ContentValues();
            values.put(COLUMN_USER_DAYS_STUDIED, getDaysStudied(userId) + 1); // Incrementa os dias estudados
            values.put(COLUMN_USER_CURRENT_STREAK, currentStreak); // Atualiza a sequência
            db.update(TABLE_USERS, values, COLUMN_USER_ID + " = ?", new String[]{String.valueOf(userId)});
        } catch (SQLiteException e) {
            Log.e("DatabaseHelper", "Erro ao atualizar dados de estudo do usuário: " + e.getMessage());
        } finally {
            if (db != null) {
                db.close();
            }
        }
    }
    // Método para obter o ID do usuário pelo nome de usuário
    public int getUserId(String username) {
        SQLiteDatabase db = null;
        Cursor cursor = null;
        try {
            db = this.getReadableDatabase();
            String[] columns = {COLUMN_USER_ID};
            String selection = COLUMN_USER_USERNAME + " = ?";
            String[] selectionArgs = {username};
            cursor = db.query(TABLE_USERS, columns, selection, selectionArgs, null, null, null);
            if (cursor.moveToFirst()) {
                return cursor.getInt(cursor.getColumnIndex(COLUMN_USER_ID));
            }
        } catch (SQLiteException e) {
            Log.e("DatabaseHelper", "Erro ao obter ID do usuário: " + e.getMessage());
        } finally {
            if (cursor != null) {
                cursor.close();
            }
            if (db != null) {
                db.close();
            }
        }
        return -1;
    }
    // Método para obter os dados do usuário
    public Usuario getUser(String username) {
        SQLiteDatabase db = null;
        Cursor cursor = null;
        try {
            db = this.getReadableDatabase();
            String[] columns = {
                    COLUMN_USER_ID,
                    COLUMN_USER_USERNAME,
                    COLUMN_USER_PASSWORD,
                    COLUMN_USER_LANGUAGE,
                    COLUMN_USER_DAILY_GOAL,
                    COLUMN_USER_DAYS_STUDIED,
                    COLUMN_USER_CURRENT_STREAK
            };
            String selection = COLUMN_USER_USERNAME + " = ?";
            String[] selectionArgs = {username};
            cursor = db.query(TABLE_USERS, columns, selection, selectionArgs, null, null, null);
            if (cursor.moveToFirst()) {
                @SuppressLint("Range") int userId = cursor.getInt(cursor.getColumnIndex(COLUMN_USER_ID));
                @SuppressLint("Range") String password = cursor.getString(cursor.getColumnIndex(COLUMN_USER_PASSWORD));
                @SuppressLint("Range") String language = cursor.getString(cursor.getColumnIndex(COLUMN_USER_LANGUAGE));
                @SuppressLint("Range") int dailyGoal = cursor.getInt(cursor.getColumnIndex(COLUMN_USER_DAILY_GOAL));
                @SuppressLint("Range") int daysStudied = cursor.getInt(cursor.getColumnIndex(COLUMN_USER_DAYS_STUDIED));
                @SuppressLint("Range") int currentStreak = cursor.getInt(cursor.getColumnIndex(COLUMN_USER_CURRENT_STREAK));
                return new Usuario(userId, username, password, language, dailyGoal, daysStudied, currentStreak);
            }
        } catch (SQLiteException e) {
            Log.e("DatabaseHelper", "Erro ao obter dados do usuário: " + e.getMessage());
        } finally {
            if (cursor != null) {
                cursor.close();
            }
            if (db != null) {
                db.close();
            }
        }
        return null;
    }

    // Método para obter os registros de estudo de um usuário
    public List<Estudo> getStudyRecords(String username) {
        List<Estudo> studyRecords = new ArrayList<>();
        SQLiteDatabase db = null;
        Cursor cursor = null;
        try {
            db = this.getReadableDatabase();
            int userId = getUserId(username);
            if (userId == -1) {
                Log.e("DatabaseHelper", "Usuário não encontrado para obter registros de estudo.");
                throw new SQLiteException("Usuário não encontrado");
            }
            String selection = COLUMN_STUDY_RECORD_USER_ID + " = ?";
            String[] selectionArgs = {String.valueOf(userId)};
            cursor = db.query(TABLE_STUDY_RECORDS, null, selection, selectionArgs, null, null, null);
            if (cursor.moveToFirst()) {
                do {
                    try {
                        @SuppressLint("Range") int studyRecordId = cursor.getInt(cursor.getColumnIndex(COLUMN_STUDY_RECORD_ID));
                        @SuppressLint("Range") Date date = dateFormat.parse(cursor.getString(cursor.getColumnIndex(COLUMN_STUDY_RECORD_DATE)));
                        @SuppressLint("Range") String content = cursor.getString(cursor.getColumnIndex(COLUMN_STUDY_RECORD_CONTENT));
                        studyRecords.add(new Estudo(studyRecordId, userId, date, content));
                    } catch (ParseException e) {
                        Log.e("DatabaseHelper", "Erro ao analisar data do registro de estudo: " + e.getMessage());
                        throw new SQLiteException("Erro ao analisar data do registro de estudo");
                    }
                } while (cursor.moveToNext());
            }
        } catch (SQLiteException e) {
            Log.e("DatabaseHelper", "Erro ao obter registros de estudo: " + e.getMessage());
            // Propaga a exceção para ser tratada na Activity
            throw e;
        } finally {
            if (cursor != null) {
                cursor.close();
            }
            if (db != null) {
                db.close();
            }
        }
        return studyRecords;
    }
    // Método para obter o ranking dos usuários
    public List<Usuario> getRanking() {
        List<Usuario> users = new ArrayList<>();
        SQLiteDatabase db = null;
        Cursor cursor = null;
        try {
            db = this.getReadableDatabase();
            String query = "SELECT * FROM " + TABLE_USERS + " ORDER BY " + COLUMN_USER_DAYS_STUDIED + " DESC";
            cursor = db.rawQuery(query, null);
            if (cursor.moveToFirst()) {
                do {
                    @SuppressLint("Range") int userId = cursor.getInt(cursor.getColumnIndex(COLUMN_USER_ID));
                    @SuppressLint("Range") String username = cursor.getString(cursor.getColumnIndex(COLUMN_USER_USERNAME));
                    @SuppressLint("Range") String password = cursor.getString(cursor.getColumnIndex(COLUMN_USER_PASSWORD));
                    @SuppressLint("Range") String language = cursor.getString(cursor.getColumnIndex(COLUMN_USER_LANGUAGE));
                    @SuppressLint("Range") int dailyGoal = cursor.getInt(cursor.getColumnIndex(COLUMN_USER_DAILY_GOAL));
                    @SuppressLint("Range") int daysStudied = cursor.getInt(cursor.getColumnIndex(COLUMN_USER_DAYS_STUDIED));
                    @SuppressLint("Range") int currentStreak = cursor.getInt(cursor.getColumnIndex(COLUMN_USER_CURRENT_STREAK));
                    users.add(new Usuario(userId, username, password, language, dailyGoal, daysStudied, currentStreak));
                } while (cursor.moveToNext());
            }
        } catch (SQLiteException e) {
            Log.e("DatabaseHelper", "Erro ao obter ranking: " + e.getMessage());
        } finally {
            if (cursor != null) {
                cursor.close();
            }
            if (db != null) {
                db.close();
            }
        }
        return users;
    }

    // Método para obter a data do último estudo do usuário
    private Date getLastStudyDate(int userId) {
        SQLiteDatabase db = null;
        Cursor cursor = null;
        try {
            db = this.getReadableDatabase();
            String query = "SELECT " + COLUMN_STUDY_RECORD_DATE + " FROM " + TABLE_STUDY_RECORDS +
                    " WHERE " + COLUMN_STUDY_RECORD_USER_ID + " = ?" +
                    " ORDER BY " + COLUMN_STUDY_RECORD_DATE + " DESC LIMIT 1";
            cursor = db.rawQuery(query, new String[]{String.valueOf(userId)});
            if (cursor.moveToFirst()) {
                try {
                    return dateFormat.parse(cursor.getString(cursor.getColumnIndex(COLUMN_STUDY_RECORD_DATE)));
                } catch (ParseException e) {
                    Log.e("DatabaseHelper", "Erro ao analisar data do último estudo: " + e.getMessage());
                }
            }
        } catch (SQLiteException e) {
            Log.e("DatabaseHelper", "Erro ao obter data do último estudo: " + e.getMessage());
        } finally {
            if (cursor != null) {
                cursor.close();
            }
            if (db != null) {
                db.close();
            }
        }
        return null;
    }

    // Método para obter a quantidade de dias estudados do usuário
    private int getDaysStudied(int userId) {
        SQLiteDatabase db = null;
        Cursor cursor = null;
        try {
            db = this.getReadableDatabase();
            String query = "SELECT " + COLUMN_USER_DAYS_STUDIED + " FROM " + TABLE_USERS + " WHERE " + COLUMN_USER_ID + " = ?";
            cursor = db.rawQuery(query, new String[]{String.valueOf(userId)});
            if (cursor.moveToFirst()) {
                return cursor.getInt(cursor.getColumnIndex(COLUMN_USER_DAYS_STUDIED));
            }
        } catch (SQLiteException e) {
            Log.e("DatabaseHelper", "Erro ao obter dias estudados: " + e.getMessage());
        } finally {
            if (cursor != null) {
                cursor.close();
            }
            if (db != null) {
                db.close();
            }
        }
        return 0;
    }


    // Método para obter a sequência atual do usuário
    private int getCurrentStreak(int userId) {
        SQLiteDatabase db = null;
        Cursor cursor = null;
        try {
            db = this.getReadableDatabase();
            String query = "SELECT " + COLUMN_USER_CURRENT_STREAK + " FROM " + TABLE_USERS + " WHERE " + COLUMN_USER_ID + " = ?";
            cursor = db.rawQuery(query, new String[]{String.valueOf(userId)});
            if (cursor.moveToFirst()) {
                return cursor.getInt(cursor.getColumnIndex(COLUMN_USER_CURRENT_STREAK));
            }
        } catch (SQLiteException e) {
            Log.e("DatabaseHelper", "Erro ao obter sequência atual: " + e.getMessage());
        } finally {
            if (cursor != null) {
                cursor.close();
            }
            if (db != null) {
                db.close();
            }
        }
        return 0;
    }
}