package com.example.devcontabiliza;

import java.util.Date;

public class Estudo {
    private int studyRecordId;
    private int userId;
    private Date date;
    private String content;

    // Construtor com data e conteúdo
    public Estudo(Date date, String content) {
        this.date = date;
        this.content = content;
    }

    // Construtor com ID do registro, ID do usuário, data e conteúdo
    public Estudo(int studyRecordId, int userId, Date date, String content) {
        this.studyRecordId = studyRecordId;
        this.userId = userId;
        this.date = date;
        this.content = content;
    }

    // Construtor vazio
    public Estudo() {
        this.date = new Date();
    }

    // Getters e setters
    public int getStudyRecordId() {
        return studyRecordId;
    }

    public void setStudyRecordId(int studyRecordId) {
        this.studyRecordId = studyRecordId;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }
}