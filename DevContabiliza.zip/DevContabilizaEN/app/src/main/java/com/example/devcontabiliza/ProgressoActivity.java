package com.example.devcontabiliza;

import android.content.Intent;
import android.database.sqlite.SQLiteException;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Locale;

public class ProgressoActivity extends AppCompatActivity {

    private TextView txtDiasEstudados, txtSequencia, txtMeta;
    private LinearLayout layoutConteudos;
    private Button btRanking;
    private DatabaseHelper dbHelper;
    private SimpleDateFormat dateFormat;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_progresso);

        txtDiasEstudados = findViewById(R.id.txtDiasEstudados);
        txtSequencia = findViewById(R.id.txtSequencia);
        txtMeta = findViewById(R.id.txtMeta);
        btRanking = findViewById(R.id.btRanking);
        layoutConteudos = findViewById(R.id.layoutConteudos);
        dbHelper = new DatabaseHelper(this);
        dateFormat = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());

        String username = getIntent().getStringExtra("username");

        if (username != null) {
            try {
                Usuario usuario = dbHelper.getUser(username);
                if (usuario != null) {
                    txtDiasEstudados.setText("Dias estudados: " + usuario.getDaysStudied());
                    txtSequencia.setText("Sequência atual: " + usuario.getCurrentStreak());
                    txtMeta.setText("Meta: " + usuario.getDailyGoal() + " dias");

                    List<Estudo> studyRecords = dbHelper.getStudyRecords(username);
                    for (Estudo estudo : studyRecords) {
                        TextView textView = new TextView(this);
                        textView.setText(dateFormat.format(estudo.getDate()) + ": " + estudo.getContent());
                        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);

                        params.setMargins(0, 8, 0, 8);
                        textView.setLayoutParams(params);


                        layoutConteudos.addView(textView);
                    }
                } else {
                    Toast.makeText(this, "Usuário não encontrado.", Toast.LENGTH_SHORT).show();
                    Log.e("ProgressoActivity", "Usuário não encontrado: " + username);
                }
            } catch (SQLiteException e) {
                Toast.makeText(this, "Erro ao carregar dados: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                Log.e("ProgressoActivity", "Erro ao carregar dados", e);
            } catch (Exception e) {
                Toast.makeText(this, "Erro ao carregar dados.", Toast.LENGTH_SHORT).show();
                Log.e("ProgressoActivity", "Erro ao carregar dados", e);
            }
        } else {
            Toast.makeText(this, "Usuário não encontrado.", Toast.LENGTH_SHORT).show();
            Log.e("ProgressoActivity", "Nome de usuário não existente.");
        }

        btRanking.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ProgressoActivity.this, RankingActivity.class);
                startActivity(intent);
            }
        });
    }
}