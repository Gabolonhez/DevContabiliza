package com.example.devcontabiliza;

import android.content.Intent;
import android.content.SharedPreferences;
import android.database.sqlite.SQLiteException;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import java.util.Date;

public class EstudoActivity extends AppCompatActivity {
    private CheckBox checkEstudou;
    private EditText edConteudo;
    private Button buttonSalvar, btVerificarProgresso;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_estudo);

        checkEstudou = findViewById(R.id.checkEstudou);
        edConteudo = findViewById(R.id.edConteudo);
        buttonSalvar = findViewById(R.id.buttonSalvar);
        dbHelper = new DatabaseHelper(this);
        btVerificarProgresso = findViewById(R.id.btVerificarProgresso);

        buttonSalvar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = getLoggedInUsername(); // Obtém o nome de usuário aqui
                if (username != null) {
                    boolean estudouHoje = checkEstudou.isChecked();
                    String content = edConteudo.getText().toString();

                    if (estudouHoje) {
                        if (content.isEmpty()) {
                            Toast.makeText(EstudoActivity.this, "Descreva o que você estudou.", Toast.LENGTH_SHORT).show();
                            return;
                        }

                        try {
                            Estudo estudo = new Estudo();
                            estudo.setUserId(dbHelper.getUserId(username));
                            estudo.setContent(content);
                            estudo.setDate(new Date());
                            dbHelper.insertStudyRegister(estudo);

                            Toast.makeText(EstudoActivity.this, "Registro salvo com sucesso!", Toast.LENGTH_SHORT).show();

                            // Inicia a ProgressoActivity
                            Intent intent = new Intent(EstudoActivity.this, ProgressoActivity.class);
                            intent.putExtra("username", username);
                            startActivity(intent);

                            checkEstudou.setChecked(false);
                            edConteudo.setText("");
                        } catch (SQLiteException e) {
                            Toast.makeText(EstudoActivity.this, "Erro ao salvar estudo: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(EstudoActivity.this, "Marque a caixa 'Estudou hoje?' para registrar.", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(EstudoActivity.this, "Você precisa estar logado para salvar um estudo.", Toast.LENGTH_SHORT).show();
                    // Redireciona para a tela de login e finaliza a activity atual
                    Intent intent = new Intent(EstudoActivity.this, ProgressoActivity.class);
                    startActivity(intent);
                    finish();
                }
            }
        });

        btVerificarProgresso.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = getLoggedInUsername(); // Obtém o nome de usuário aqui
                if (username != null) {
                    Intent intent = new Intent(EstudoActivity.this, ProgressoActivity.class);
                    intent.putExtra("username", username);
                    startActivity(intent);
                } else {
                    Toast.makeText(EstudoActivity.this, "Você precisa estar logado para verificar o progresso.", Toast.LENGTH_SHORT).show();
                    // Redireciona para a tela de login e finaliza a activity atual
                    Intent intent = new Intent(EstudoActivity.this, LoginActivity.class);
                    startActivity(intent);
                    finish();
                }
            }
        });
    }

    private String getLoggedInUsername() {
        SharedPreferences preferences = getSharedPreferences("UserPrefs", MODE_PRIVATE);
        return preferences.getString("username", null);
    }
}