package com.example.devcontabiliza;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.database.sqlite.SQLiteException;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class CadastroActivity extends AppCompatActivity {

    private EditText edUsuario, edSenha, edLinguagem, edMeta;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro);

        edUsuario = findViewById(R.id.edUsuario);
        edSenha = findViewById(R.id.edSenha);
        edLinguagem = findViewById(R.id.edLinguagem);
        edMeta = findViewById(R.id.edMeta);
        Button cadastroButton = findViewById(R.id.cadastroButton);
        dbHelper = new DatabaseHelper(this);

        cadastroButton.setOnClickListener(view -> {
            String username = edUsuario.getText().toString();
            String password = edSenha.getText().toString();
            String language = edLinguagem.getText().toString();
            String meta = edMeta.getText().toString();

            if (username.isEmpty() || password.isEmpty() || language.isEmpty() || meta.isEmpty()) {
                Toast.makeText(CadastroActivity.this, "Preencha todos os campos.", Toast.LENGTH_SHORT).show();
            } else {
                try {
                    int metaInt = Integer.parseInt(meta);

                    // Verifica se o usuário já existe
                    if (dbHelper.getUser(username) != null) {
                        Toast.makeText(CadastroActivity.this, "Nome de usuário já existe.", Toast.LENGTH_SHORT).show();
                    } else {
                        dbHelper.insertUser(username, password, language, metaInt);
                        Toast.makeText(CadastroActivity.this, "Usuário cadastrado com sucesso!", Toast.LENGTH_SHORT).show();

                        // Limpa os campos após o cadastro
                        edUsuario.setText("");
                        edSenha.setText("");
                        edLinguagem.setText("");
                        edMeta.setText("");

                        // Inicia a LoginActivity
                        Intent intent = new Intent(CadastroActivity.this, LoginActivity.class);
                        startActivity(intent);
                    }
                } catch (NumberFormatException e) {
                    Toast.makeText(CadastroActivity.this, "Meta diária inválida.", Toast.LENGTH_SHORT).show();
                    Log.e("CadastroActivity", "Erro ao converter meta para inteiro: " + e.getMessage());
                } catch (SQLiteException e) {
                    Toast.makeText(CadastroActivity.this, "Erro ao cadastrar usuário.", Toast.LENGTH_SHORT).show();
                    Log.e("CadastroActivity", "Erro ao inserir usuário no banco de dados: " + e.getMessage());
                }
            }
        });
    }
}