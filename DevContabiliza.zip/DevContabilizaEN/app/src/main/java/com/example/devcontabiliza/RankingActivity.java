package com.example.devcontabiliza;

import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import java.util.List;

public class RankingActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ranking);

        dbHelper = new DatabaseHelper(this);
        LinearLayout linearLayoutRanking = findViewById(R.id.linearLayoutRanking);

        List<Usuario> ranking = dbHelper.getRanking();

        if (ranking.isEmpty()) {
            TextView noRankingText = new TextView(this);
            noRankingText.setText("Nenhum usuário no ranking ainda.");
            noRankingText.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
            linearLayoutRanking.addView(noRankingText);
        } else {
            for (Usuario usuario : ranking) {
                LinearLayout itemRanking = new LinearLayout(this);
                itemRanking.setOrientation(LinearLayout.HORIZONTAL);

                LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                params.setMargins(0, 16, 0, 16);
                itemRanking.setLayoutParams(params);


                TextView textViewNome = new TextView(this);
                textViewNome.setText(usuario.getUsername());
                textViewNome.setTextSize(16);
                textViewNome.setPadding(10, 0, 0, 0);

                LinearLayout.LayoutParams nomeParams = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
                textViewNome.setLayoutParams(nomeParams);

                TextView textViewDiasEstudados = new TextView(this);
                textViewDiasEstudados.setText(usuario.getDaysStudied() + " dias estudados");
                textViewDiasEstudados.setTextSize(14);
                textViewDiasEstudados.setPadding(10, 0, 0, 0);

                LinearLayout.LayoutParams diasParams = new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.WRAP_CONTENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                );
                textViewDiasEstudados.setLayoutParams(diasParams);

                TextView textViewSequenciaDias = new TextView(this);
                textViewSequenciaDias.setText(usuario.getCurrentStreak() + " dias em sequência");
                textViewSequenciaDias.setTextSize(14);
                textViewSequenciaDias.setPadding(10, 0, 10, 0);

                LinearLayout.LayoutParams sequenciaParams = new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.WRAP_CONTENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                );
                textViewSequenciaDias.setLayoutParams(sequenciaParams);

                itemRanking.addView(textViewNome);
                itemRanking.addView(textViewDiasEstudados);
                itemRanking.addView(textViewSequenciaDias);

                linearLayoutRanking.addView(itemRanking);
            }
        }
    }
}