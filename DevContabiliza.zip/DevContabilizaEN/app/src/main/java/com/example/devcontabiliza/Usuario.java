package com.example.devcontabiliza;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class Usuario {
    private int userId;
    private String username;
    private String password;
    private String studyLanguage;
    private int dailyGoal;
    private int daysStudied;
    private int currentStreak;
    private List<Estudo> studyRecords;
    private Date lastStudyDate;

    // Construtor para novos usuários
    public Usuario(String username, String password, String studyLanguage, int dailyGoal) {
        this.username = username;
        this.password = password;
        this.studyLanguage = studyLanguage;
        this.dailyGoal = dailyGoal;
        this.daysStudied = 0;
        this.currentStreak = 0;
        this.studyRecords = new ArrayList<>();
        this.lastStudyDate = null; // Inicializa a data do último estudo como nulo
    }

    // Construtor para usuários existentes (obtidos do banco de dados)
    public Usuario(int userId, String username, String password, String studyLanguage, int dailyGoal, int daysStudied, int currentStreak) {
        this.userId = userId;
        this.username = username;
        this.password = password;
        this.studyLanguage = studyLanguage;
        this.dailyGoal = dailyGoal;
        this.daysStudied = daysStudied;
        this.currentStreak = currentStreak;
        this.studyRecords = new ArrayList<>();
    }

    // Getters e setters
    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getStudyLanguage() {
        return studyLanguage;
    }

    public void setStudyLanguage(String studyLanguage) {
        this.studyLanguage = studyLanguage;
    }

    public int getDailyGoal() {
        return dailyGoal;
    }

    public void setDailyGoal(int dailyGoal) {
        this.dailyGoal = dailyGoal;
    }

    public int getDaysStudied() {
        return daysStudied;
    }

    public void setDaysStudied(int daysStudied) {
        this.daysStudied = daysStudied;
    }

    public int getCurrentStreak() {
        return currentStreak;
    }

    public void setCurrentStreak(int currentStreak) {
        this.currentStreak = currentStreak;
    }

    public List<Estudo> getStudyRecords() {
        return studyRecords;
    }

    public void setStudyRecords(List<Estudo> studyRecords) {
        this.studyRecords = studyRecords;
    }

    // Método para registrar um novo estudo
    public void registerStudy(Estudo record) {
        this.studyRecords.add(record);
        this.daysStudied++;

        if (lastStudyDate == null) {
            // Primeiro registro de estudo
            currentStreak = 1;
        } else {
            // Calcula a diferença em dias entre a data do novo estudo e a data do último estudo
            long diff = record.getDate().getTime() - lastStudyDate.getTime();
            long daysDifference = TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS);

            if (daysDifference == 1) {
                // Se a diferença for de um dia, incrementa a sequência
                currentStreak++;
            } else {
                // Se a diferença for maior que um dia, reinicia a sequência
                currentStreak = 1;
            }
        }

        lastStudyDate = record.getDate(); // Atualiza a data do último estudo
    }

    public Date getLastStudyDate() {
        return lastStudyDate;
    }

    public void setLastStudyDate(Date lastStudyDate) {
        this.lastStudyDate = lastStudyDate;
    }
}